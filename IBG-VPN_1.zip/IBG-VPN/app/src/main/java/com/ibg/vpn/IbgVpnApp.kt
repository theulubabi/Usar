package com.ibg.vpn

import android.app.Application
import com.ibg.vpn.data.SecureConfigStore
import com.ibg.vpn.data.SettingsStore
import com.ibg.vpn.vpn.VpnManager

/**
 * Application class acting as a minimal manual dependency container.
 * Everything here is a process-wide singleton.
 */
class IbgVpnApp : Application() {
    lateinit var secureStore: SecureConfigStore
        private set
    lateinit var settingsStore: SettingsStore
        private set
    lateinit var vpnManager: VpnManager
        private set

    override fun onCreate() {
        super.onCreate()
        secureStore = SecureConfigStore(this)
        settingsStore = SettingsStore(this)
        vpnManager = VpnManager(this, secureStore, settingsStore)
    }
}
