package com.ibg.vpn.data

import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import java.io.ByteArrayInputStream

/**
 * User-entered WireGuard settings for one location. Nothing here is hard-coded:
 * values are entered in the app (Settings → Servers) and stored encrypted.
 */
data class ServerConfig(
    val endpointHost: String = "",
    val port: Int = DEFAULT_PORT,
    val serverPublicKey: String = "",
    val clientPrivateKey: String = "",
    /** e.g. "10.8.0.2/32" or "10.8.0.2/32, fd00::2/128" */
    val clientAddress: String = "",
    /** e.g. "1.1.1.1" — required so DNS is forced through the tunnel. */
    val dns: String = "",
    /** Optional pre-shared key. */
    val presharedKey: String = "",
) {
    val isComplete: Boolean
        get() = endpointHost.isNotBlank() && port in 1..65535 &&
            serverPublicKey.isNotBlank() && clientPrivateKey.isNotBlank() &&
            clientAddress.isNotBlank() && dns.isNotBlank()

    /**
     * Builds a WireGuard [Config] that routes ALL traffic through the tunnel:
     *  - AllowedIPs 0.0.0.0/0 (every IPv4 packet)
     *  - AllowedIPs ::/0 (every IPv6 packet). If the server has no IPv6, those packets are
     *    dropped inside the tunnel instead of leaking out over the ISP's IPv6.
     *  - DNS servers are pushed to the VPN interface, so lookups also travel in the tunnel.
     */
    @Throws(BadConfigException::class, IllegalArgumentException::class)
    fun toWireGuardConfig(): Config {
        require(isComplete) { "Incomplete configuration" }
        val iface = Interface.Builder()
            .parsePrivateKey(clientPrivateKey.trim())
            .parseAddresses(clientAddress.trim())
            .parseDnsServers(dns.trim())
            .build()

        val host = endpointHost.trim().let {
            if (it.contains(':') && !it.startsWith("[")) "[$it]" else it   // IPv6 literal
        }
        val peer = Peer.Builder()
            .parsePublicKey(serverPublicKey.trim())
            .parseEndpoint("$host:$port")
            .parseAllowedIPs(FULL_TUNNEL_ALLOWED_IPS)
            .setPersistentKeepalive(KEEPALIVE_SECONDS)
            .apply { if (presharedKey.isNotBlank()) parsePreSharedKey(presharedKey.trim()) }
            .build()

        return Config.Builder().setInterface(iface).addPeer(peer).build()
    }

    companion object {
        const val DEFAULT_PORT = 51820
        const val KEEPALIVE_SECONDS = 25
        const val FULL_TUNNEL_ALLOWED_IPS = "0.0.0.0/0, ::/0"

        /**
         * Imports a standard wg-quick .conf (as exported by most WireGuard servers).
         * Only the first peer is used; AllowedIPs are always forced to full-tunnel.
         */
        @Throws(Exception::class)
        fun fromWgQuick(text: String): ServerConfig {
            val cfg = Config.parse(ByteArrayInputStream(text.toByteArray()))
            val i = cfg.`interface`
            val p = cfg.peers.firstOrNull() ?: throw IllegalArgumentException("No [Peer] section")
            val ep = p.endpoint.orElse(null) ?: throw IllegalArgumentException("Peer has no Endpoint")
            return ServerConfig(
                endpointHost = ep.host,
                port = ep.port,
                serverPublicKey = p.publicKey.toBase64(),
                clientPrivateKey = i.keyPair.privateKey.toBase64(),
                clientAddress = i.addresses.joinToString(", ") { it.toString() },
                dns = i.dnsServers.joinToString(", ") { it.hostAddress ?: "" },
                presharedKey = p.preSharedKey.map { it.toBase64() }.orElse(""),
            )
        }
    }
}
