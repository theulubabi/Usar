package com.ibg.vpn.ui.screens

import android.app.Activity
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ibg.vpn.R
import com.ibg.vpn.ui.MainViewModel
import com.ibg.vpn.vpn.ConnectionState
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel, onOpenLocations: () -> Unit, onOpenSettings: () -> Unit) {
    val status by vm.status.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val conn = status.connection

    // Android VPN consent dialog.
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) vm.connect() else vm.onPermissionDenied()
    }

    val visual = when (conn) {
        is ConnectionState.Connected -> ButtonVisual.CONNECTED
        ConnectionState.Disconnected -> ButtonVisual.IDLE
        else -> ButtonVisual.BUSY
    }
    val title = stringResource(
        when (conn) {
            is ConnectionState.Connected -> R.string.state_protected
            ConnectionState.Connecting -> R.string.state_connecting
            ConnectionState.Verifying -> R.string.state_verifying
            is ConnectionState.Reconnecting -> R.string.state_reconnecting
            ConnectionState.Disconnecting -> R.string.state_disconnecting
            ConnectionState.Disconnected -> R.string.state_not_connected
        }
    )

    val onToggle: () -> Unit = {
        when (conn) {
            ConnectionState.Disconnected -> {
                vm.clearError()
                val intent = vm.vpnPermissionIntent()
                if (intent != null) permissionLauncher.launch(intent) else vm.connect()
            }
            ConnectionState.Disconnecting -> Unit
            else -> vm.disconnect()   // also cancels a connect that is in progress
        }
    }

    // Live connection timer
    val since = when (conn) {
        is ConnectionState.Connected -> conn.sinceElapsed
        is ConnectionState.Reconnecting -> conn.sinceElapsed
        else -> null
    }
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(since) {
        while (since != null) { now = SystemClock.elapsedRealtime(); delay(1000) }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("IBG VPN", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) },
                actions = { IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Settings, "Settings") } },
            )
        }
    ) { pad ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(pad)) {
            val buttonSize = (minOf(maxWidth, maxHeight) * 0.62f).coerceIn(180.dp, 300.dp)
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(8.dp))
                ConnectButton(visual, buttonSize, if (visual == ButtonVisual.IDLE) "Connect" else "Disconnect", onToggle)
                Spacer(Modifier.height(12.dp))
                Text(
                    title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold,
                    color = if (visual == ButtonVisual.CONNECTED) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onBackground
                )

                status.error?.let { err ->
                    Spacer(Modifier.height(12.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(10.dp))
                            Text(stringResource(err.message), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Card(onClick = onOpenLocations, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(settings.location.flag, fontSize = 32.sp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Selected Location", style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(settings.location.displayName, style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold)
                        }
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Change location")
                    }
                }

                Spacer(Modifier.height(12.dp))
                Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        val ip = (conn as? ConnectionState.Connected)?.let { it.publicIp ?: "Unavailable" } ?: "—"
                        InfoRow("VPN IP", ip)
                        InfoRow("Tunnel IP", status.tunnelAddress ?: "—")
                        InfoRow("Connection Time", since?.let { formatDuration(now - it) } ?: "—")
                        InfoRow("Protocol", "WireGuard")
                    }
                }
            }
        }
    }
}

@Composable
internal fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.Medium)
    }
}

private fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
}
