package com.ibg.vpn.vpn

import com.ibg.vpn.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Fetches the public exit IP over HTTPS. Called only AFTER the tunnel is up, so the request
 * itself travels through the VPN and the answer is the VPN server's exit address.
 * No identifiers, cookies or device data are sent. Endpoint is configurable in app/build.gradle.kts.
 */
object PublicIpFetcher {
    private val IPV4_OR_V6 = Regex("^[0-9a-fA-F:.]{3,45}$")

    suspend fun fetch(): String? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = URL(BuildConfig.IP_CHECK_URL).openConnection() as HttpsURLConnection
            try {
                conn.connectTimeout = 8_000
                conn.readTimeout = 8_000
                conn.useCaches = false
                conn.setRequestProperty("User-Agent", "IBG-VPN")
                conn.inputStream.bufferedReader().use { it.readText().trim() }
            } finally {
                conn.disconnect()
            }
        }.getOrNull()?.takeIf { IPV4_OR_V6.matches(it) }
    }
}
