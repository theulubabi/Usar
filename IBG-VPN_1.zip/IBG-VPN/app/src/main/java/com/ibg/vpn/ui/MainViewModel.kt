package com.ibg.vpn.ui

import android.app.Application
import android.content.Intent
import android.net.VpnService
import androidx.lifecycle.AndroidViewModel
import com.ibg.vpn.IbgVpnApp
import com.ibg.vpn.data.AppSettings
import com.ibg.vpn.data.ServerConfig
import com.ibg.vpn.data.VpnLocation
import com.ibg.vpn.vpn.ConnectionState
import com.ibg.vpn.vpn.VpnError
import com.ibg.vpn.vpn.VpnStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val container = app as IbgVpnApp
    private val vpn = container.vpnManager
    private val settingsStore = container.settingsStore
    private val secureStore = container.secureStore

    val status: StateFlow<VpnStatus> = vpn.status
    val settings: StateFlow<AppSettings> = settingsStore.settings

    /** Bumped whenever server configs change so the UI re-reads "configured" state. */
    private val _configVersion = MutableStateFlow(0)
    val configVersion: StateFlow<Int> = _configVersion.asStateFlow()

    init {
        // Auto-connect when the app opens (only if the user enabled it and consent already exists).
        val s = settingsStore.current
        if (s.autoConnect && vpn.isPermissionGranted() &&
            status.value.connection == ConnectionState.Disconnected &&
            secureStore.isConfigured(s.location)
        ) vpn.connect(s.location)
    }

    /** Returns the system consent Intent if VPN permission is still needed, else null. */
    fun vpnPermissionIntent(): Intent? = VpnService.prepare(getApplication())

    fun connect() = vpn.connect(settings.value.location)
    fun disconnect() = vpn.disconnect()
    fun clearError() = vpn.clearError()
    fun onPermissionDenied() = vpn.reportError(VpnError.PERMISSION_DENIED)

    fun selectLocation(location: VpnLocation) {
        settingsStore.setLocation(location)
        // If already connected elsewhere, switch the tunnel to the new country.
        val c = status.value.connection
        if ((c is ConnectionState.Connected || c is ConnectionState.Reconnecting) &&
            status.value.location != location
        ) vpn.connect(location)
    }

    fun isConfigured(location: VpnLocation) = secureStore.isConfigured(location)
    fun loadConfig(location: VpnLocation) = secureStore.load(location)
    fun saveConfig(location: VpnLocation, cfg: ServerConfig) {
        secureStore.save(location, cfg); _configVersion.value++
    }
    fun clearConfig(location: VpnLocation) {
        secureStore.clear(location); _configVersion.value++
    }

    fun setAutoConnect(v: Boolean) = settingsStore.setAutoConnect(v)
    fun setConnectOnBoot(v: Boolean) = settingsStore.setConnectOnBoot(v)
    fun setKillSwitch(v: Boolean) = settingsStore.setKillSwitch(v)
}
