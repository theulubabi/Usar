package com.ibg.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ibg.vpn.data.VpnLocation
import com.ibg.vpn.ui.MainViewModel
import com.ibg.vpn.ui.screens.HomeScreen
import com.ibg.vpn.ui.screens.LocationScreen
import com.ibg.vpn.ui.screens.ServerConfigScreen
import com.ibg.vpn.ui.screens.SettingsScreen
import com.ibg.vpn.ui.theme.IbgVpnTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IbgVpnTheme {
                val vm: MainViewModel = viewModel()
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(vm,
                            onOpenLocations = { nav.navigate("locations") },
                            onOpenSettings = { nav.navigate("settings") })
                    }
                    composable("locations") {
                        LocationScreen(vm, onBack = { nav.popBackStack() },
                            onConfigure = { nav.navigate("config/${it.id}") })
                    }
                    composable("settings") {
                        SettingsScreen(vm, onBack = { nav.popBackStack() },
                            onConfigure = { nav.navigate("config/${it.id}") })
                    }
                    composable("config/{loc}") { entry ->
                        ServerConfigScreen(vm,
                            location = VpnLocation.fromId(entry.arguments?.getString("loc")),
                            onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
