package com.ibg.vpn.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores WireGuard keys and server details encrypted at rest.
 * The AES-256 master key lives in the Android Keystore and never leaves it.
 * Backups are disabled in the manifest, so keys are never copied off the device.
 */
class SecureConfigStore(context: Context) {

    private val prefs: SharedPreferences = run {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "ibg_secure_servers",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    fun load(location: VpnLocation): ServerConfig {
        val p = location.id
        return ServerConfig(
            endpointHost = prefs.getString("$p.host", "") ?: "",
            port = prefs.getInt("$p.port", ServerConfig.DEFAULT_PORT),
            serverPublicKey = prefs.getString("$p.serverPub", "") ?: "",
            clientPrivateKey = prefs.getString("$p.clientPriv", "") ?: "",
            clientAddress = prefs.getString("$p.address", "") ?: "",
            dns = prefs.getString("$p.dns", "") ?: "",
            presharedKey = prefs.getString("$p.psk", "") ?: "",
        )
    }

    fun save(location: VpnLocation, cfg: ServerConfig) {
        val p = location.id
        prefs.edit()
            .putString("$p.host", cfg.endpointHost.trim())
            .putInt("$p.port", cfg.port)
            .putString("$p.serverPub", cfg.serverPublicKey.trim())
            .putString("$p.clientPriv", cfg.clientPrivateKey.trim())
            .putString("$p.address", cfg.clientAddress.trim())
            .putString("$p.dns", cfg.dns.trim())
            .putString("$p.psk", cfg.presharedKey.trim())
            .apply()
    }

    fun clear(location: VpnLocation) {
        val p = location.id
        prefs.edit().apply {
            listOf("host", "port", "serverPub", "clientPriv", "address", "dns", "psk")
                .forEach { remove("$p.$it") }
        }.apply()
    }

    fun isConfigured(location: VpnLocation): Boolean = load(location).isComplete
}
