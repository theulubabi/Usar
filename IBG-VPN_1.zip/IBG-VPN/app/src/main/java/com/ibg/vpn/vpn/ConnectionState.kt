package com.ibg.vpn.vpn

import androidx.annotation.StringRes
import com.ibg.vpn.R
import com.ibg.vpn.data.VpnLocation

/** Lifecycle of the tunnel as shown to the user. "Connected" is only reached after a verified handshake. */
sealed interface ConnectionState {
    data object Disconnected : ConnectionState
    data object Connecting : ConnectionState
    data object Verifying : ConnectionState
    /** [sinceElapsed] is SystemClock.elapsedRealtime() when the tunnel was verified. */
    data class Connected(val sinceElapsed: Long, val publicIp: String?) : ConnectionState
    data class Reconnecting(val sinceElapsed: Long) : ConnectionState
    data object Disconnecting : ConnectionState
}

enum class VpnError(@StringRes val message: Int) {
    NO_INTERNET(R.string.err_no_internet),
    SERVER_UNAVAILABLE(R.string.err_server_unavailable),
    TIMEOUT(R.string.err_timeout),
    AUTH_OR_CONFIG(R.string.err_auth),
    PERMISSION_DENIED(R.string.err_permission),
    INVALID_CONFIG(R.string.err_invalid_config),
    NOT_CONFIGURED(R.string.err_not_configured),
    DNS_RESOLUTION(R.string.err_dns_resolve),
    REVOKED(R.string.err_revoked),
    START_FAILED(R.string.err_start_failed),
    UNKNOWN(R.string.err_unknown),
}

data class VpnStatus(
    val location: VpnLocation,
    val connection: ConnectionState = ConnectionState.Disconnected,
    val tunnelAddress: String? = null,
    val error: VpnError? = null,
)
