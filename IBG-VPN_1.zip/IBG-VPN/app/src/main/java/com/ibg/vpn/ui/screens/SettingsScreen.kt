package com.ibg.vpn.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.ibg.vpn.data.VpnLocation
import com.ibg.vpn.ui.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onConfigure: (VpnLocation) -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val configVersion by vm.configVersion.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showKillSwitchHelp by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Settings") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp)) {
            SectionTitle("Connection")
            Card(shape = RoundedCornerShape(18.dp)) {
                ToggleRow("Auto-connect", "Connect automatically when the app opens", s.autoConnect, vm::setAutoConnect)
                HorizontalDivider()
                ToggleRow("Connect when Android starts", "Requires VPN permission to have been granted once", s.connectOnBoot, vm::setConnectOnBoot)
                HorizontalDivider()
                ToggleRow("Kill Switch", "Block all internet when the VPN is not connected (uses Android's Always-on VPN)", s.killSwitchRequested) {
                    vm.setKillSwitch(it)
                    showKillSwitchHelp = true
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("Servers")
            Card(shape = RoundedCornerShape(18.dp)) {
                VpnLocation.entries.forEachIndexed { i, loc ->
                    val configured = remember(configVersion, loc) { vm.isConfigured(loc) }
                    if (i > 0) HorizontalDivider()
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(loc.flag, fontSize = 26.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(loc.displayName, fontWeight = FontWeight.SemiBold)
                            Text(if (configured) "Configured" else "Not configured",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { onConfigure(loc) }) {
                            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Edit ${loc.displayName}")
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("Privacy")
            Text(
                "IBG VPN does not log browsing history, contains no trackers or analytics, and sends no data to " +
                    "third parties. After connecting, one HTTPS request (through the tunnel) is made to display your VPN IP.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    if (showKillSwitchHelp) {
        AlertDialog(
            onDismissRequest = { showKillSwitchHelp = false },
            title = { Text(if (s.killSwitchRequested) "Enable Kill Switch" else "Disable Kill Switch") },
            text = {
                Text(
                    if (s.killSwitchRequested)
                        "Android only allows the system to enforce a true kill switch. On the next screen, tap the gear next to " +
                            "IBG VPN and enable both \"Always-on VPN\" and \"Block connections without VPN\"."
                    else
                        "On the next screen, tap the gear next to IBG VPN and turn off \"Block connections without VPN\"."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showKillSwitchHelp = false
                    context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Open VPN settings") }
            },
            dismissButton = { TextButton(onClick = { showKillSwitchHelp = false }) { Text("Later") } },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
