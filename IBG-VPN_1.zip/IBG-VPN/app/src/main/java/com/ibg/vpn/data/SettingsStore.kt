package com.ibg.vpn.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Non-secret user preferences. */
data class AppSettings(
    val location: VpnLocation = VpnLocation.SINGAPORE,
    val autoConnect: Boolean = false,
    val connectOnBoot: Boolean = false,
    val killSwitchRequested: Boolean = false,
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("ibg_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(
        AppSettings(
            location = VpnLocation.fromId(prefs.getString(K_LOC, null)),
            autoConnect = prefs.getBoolean(K_AUTO, false),
            connectOnBoot = prefs.getBoolean(K_BOOT, false),
            killSwitchRequested = prefs.getBoolean(K_KILL, false),
        )
    )
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()
    val current: AppSettings get() = _settings.value

    fun setLocation(l: VpnLocation) { prefs.edit().putString(K_LOC, l.id).apply(); _settings.update { it.copy(location = l) } }
    fun setAutoConnect(v: Boolean) { prefs.edit().putBoolean(K_AUTO, v).apply(); _settings.update { it.copy(autoConnect = v) } }
    fun setConnectOnBoot(v: Boolean) { prefs.edit().putBoolean(K_BOOT, v).apply(); _settings.update { it.copy(connectOnBoot = v) } }
    fun setKillSwitch(v: Boolean) { prefs.edit().putBoolean(K_KILL, v).apply(); _settings.update { it.copy(killSwitchRequested = v) } }

    private companion object {
        const val K_LOC = "location"
        const val K_AUTO = "auto_connect"
        const val K_BOOT = "connect_on_boot"
        const val K_KILL = "kill_switch"
    }
}
