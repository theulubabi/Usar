package com.ibg.vpn.vpn

import com.wireguard.android.backend.Tunnel

/** Minimal WireGuard [Tunnel] implementation that forwards backend state changes. */
class IbgTunnel(
    private val tunnelName: String,
    private val onState: (IbgTunnel, Tunnel.State) -> Unit,
) : Tunnel {
    override fun getName(): String = tunnelName
    override fun onStateChange(newState: Tunnel.State) = onState(this, newState)
}
