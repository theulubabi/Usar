package com.ibg.vpn.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

/**
 * Tracks whether a REAL (non-VPN) network with internet capability exists.
 * While our VPN is up, Android's default network is the VPN itself, so we must
 * ignore VPN networks to know whether the underlying link is alive.
 */
class NetworkMonitor(context: Context) {
    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val networks = ConcurrentHashMap.newKeySet<Network>()
    private val _online = MutableStateFlow(hasInternet())
    val online: StateFlow<Boolean> = _online.asStateFlow()

    init {
        // A default NetworkRequest already requires NOT_VPN, so VPN networks are excluded.
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        cm.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { networks.add(network); _online.value = true }
            override fun onLost(network: Network) { networks.remove(network); _online.value = hasInternet() }
        })
    }

    /** Synchronous check usable before the callback has fired. */
    @Suppress("DEPRECATION")
    fun hasInternet(): Boolean = cm.allNetworks.any { n ->
        val caps = cm.getNetworkCapabilities(n) ?: return@any false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
    }
}
