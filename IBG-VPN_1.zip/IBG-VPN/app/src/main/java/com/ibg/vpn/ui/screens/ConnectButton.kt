package com.ibg.vpn.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import com.ibg.vpn.ui.theme.Amber

enum class ButtonVisual { IDLE, BUSY, CONNECTED }

/** Large circular connect button: pulse rings when protected, spinner while connecting. */
@Composable
fun ConnectButton(visual: ButtonVisual, size: Dp, label: String, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val accent by animateColorAsState(
        when (visual) {
            ButtonVisual.CONNECTED -> scheme.primary
            ButtonVisual.BUSY -> Amber
            ButtonVisual.IDLE -> scheme.onSurfaceVariant
        }, tween(500), label = "accent"
    )
    val surface = scheme.surface
    val infinite = rememberInfiniteTransition(label = "fx")
    val pulse by infinite.animateFloat(0f, 1f,
        infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "pulse")
    val spin by infinite.animateFloat(0f, 360f,
        infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "spin")

    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .clickable(remember { MutableInteractionSource() }, indication = null, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension / 2f
            val c = center
            if (visual == ButtonVisual.CONNECTED) {
                for (i in 0..1) {
                    val p = (pulse + i * 0.5f) % 1f
                    drawCircle(accent.copy(alpha = (1f - p) * 0.35f), radius = r * (0.70f + 0.30f * p), center = c)
                }
            }
            val core = r * 0.68f
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.30f), surface), center = c, radius = core),
                radius = core, center = c)
            drawCircle(accent, radius = core, center = c, style = Stroke(width = r * 0.04f))
            if (visual == ButtonVisual.BUSY) {
                drawArc(accent, startAngle = spin, sweepAngle = 90f, useCenter = false,
                    topLeft = Offset(c.x - r * 0.80f, c.y - r * 0.80f), size = Size(r * 1.6f, r * 1.6f),
                    style = Stroke(width = r * 0.05f, cap = StrokeCap.Round))
            }
            // Power glyph
            val g = core * 0.42f
            val w = r * 0.07f
            drawArc(accent, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                topLeft = Offset(c.x - g, c.y - g), size = Size(g * 2, g * 2),
                style = Stroke(width = w, cap = StrokeCap.Round))
            drawLine(accent, Offset(c.x, c.y - g * 1.25f), Offset(c.x, c.y - g * 0.15f), strokeWidth = w, cap = StrokeCap.Round)
        }
    }
}
