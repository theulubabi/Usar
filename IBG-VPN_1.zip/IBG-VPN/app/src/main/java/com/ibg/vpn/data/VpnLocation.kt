package com.ibg.vpn.data

/**
 * Supported VPN exit locations. [tunnelName] must satisfy WireGuard naming rules
 * (max 15 chars, [a-zA-Z0-9_=+.-]).
 */
enum class VpnLocation(
    val id: String,
    val displayName: String,
    val flag: String,
    val tunnelName: String,
) {
    SINGAPORE("sg", "Singapore", "\uD83C\uDDF8\uD83C\uDDEC", "ibg-sg"),
    GERMANY("de", "Germany", "\uD83C\uDDE9\uD83C\uDDEA", "ibg-de");

    companion object {
        fun fromId(id: String?): VpnLocation = entries.firstOrNull { it.id == id } ?: SINGAPORE
    }
}
