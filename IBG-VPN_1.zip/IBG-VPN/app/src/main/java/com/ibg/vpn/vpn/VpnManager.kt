package com.ibg.vpn.vpn

import android.content.Context
import android.net.VpnService
import android.os.SystemClock
import android.util.Log
import com.ibg.vpn.data.SecureConfigStore
import com.ibg.vpn.data.SettingsStore
import com.ibg.vpn.data.VpnLocation
import com.wireguard.android.backend.BackendException
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Owns the WireGuard backend and is the single source of truth for VPN state.
 *
 * Guarantees:
 *  - "Connected" is reported only after the backend is UP *and* a WireGuard handshake with the
 *    selected server has completed (proof that packets are flowing through the tunnel).
 *  - If no handshake happens within [HANDSHAKE_TIMEOUT_MS] the tunnel is torn down and an error is shown.
 *  - A watchdog re-establishes the tunnel when handshakes go stale (auto-reconnect).
 */
class VpnManager(
    context: Context,
    private val secureStore: SecureConfigStore,
    private val settings: SettingsStore,
) {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val backend: GoBackend by lazy { GoBackend(appContext) }
    private val lock = Mutex()
    private val network = NetworkMonitor(appContext)

    private val _status = MutableStateFlow(VpnStatus(location = settings.current.location))
    val status: StateFlow<VpnStatus> = _status.asStateFlow()

    @Volatile private var activeTunnel: IbgTunnel? = null
    @Volatile private var activeConfig: Config? = null
    private var connectJob: Job? = null
    private var watchdogJob: Job? = null

    /** True while WE are bringing a tunnel down, so the DOWN callback isn't treated as a revoke. */
    @Volatile private var expectedDown = false

    init {
        // Android "Always-on VPN" (system kill switch) starts our service with no tunnel:
        // connect to the user's selected location when that happens.
        GoBackend.setAlwaysOnCallback { connect(settings.current.location) }
    }

    fun isPermissionGranted(): Boolean = VpnService.prepare(appContext) == null

    fun connect(location: VpnLocation): Job {
        connectJob?.cancel()
        return scope.launch { lock.withLock { connectLocked(location) } }.also { connectJob = it }
    }

    suspend fun connectAndAwait(location: VpnLocation) = connect(location).join()

    fun disconnect() {
        connectJob?.cancel()
        watchdogJob?.cancel()
        scope.launch {
            lock.withLock {
                setConnection(ConnectionState.Disconnecting)
                activeTunnel?.let { bringDown(it) }
                activeTunnel = null
                activeConfig = null
                _status.update { it.copy(connection = ConnectionState.Disconnected, tunnelAddress = null) }
            }
        }
    }

    fun clearError() = _status.update { it.copy(error = null) }

    /** Lets the UI surface errors that happen outside the manager (e.g. consent dialog denied). */
    fun reportError(error: VpnError) = fail(error)

    // ------------------------------------------------------------------------------------------

    private suspend fun connectLocked(location: VpnLocation) {
        watchdogJob?.cancel()
        _status.update { it.copy(location = location, connection = ConnectionState.Connecting, error = null) }

        if (!isPermissionGranted()) return fail(VpnError.PERMISSION_DENIED)
        if (!network.hasInternet()) return fail(VpnError.NO_INTERNET)

        val server = secureStore.load(location)
        if (!server.isComplete) return fail(VpnError.NOT_CONFIGURED)
        val config = try {
            server.toWireGuardConfig()
        } catch (e: BadConfigException) {
            Log.w(TAG, "Bad config: ${e.section}/${e.location}/${e.reason}")
            return fail(VpnError.INVALID_CONFIG)
        } catch (e: IllegalArgumentException) {
            return fail(VpnError.INVALID_CONFIG)
        }

        // Switching location: take the previous tunnel down first.
        activeTunnel?.let { bringDown(it) }

        val tunnel = IbgTunnel(location.tunnelName, ::onBackendState)
        activeTunnel = tunnel
        activeConfig = config

        if (!startTunnel(tunnel, config)) return

        setConnection(ConnectionState.Verifying)
        // Generate traffic in parallel: it triggers the handshake and gives us the exit IP.
        val ipLookup = scope.async { PublicIpFetcher.fetch() }
        if (!awaitHandshake(tunnel)) {
            ipLookup.cancel()
            bringDown(tunnel)
            activeTunnel = null
            return fail(if (network.hasInternet()) VpnError.SERVER_UNAVAILABLE else VpnError.TIMEOUT)
        }

        val since = SystemClock.elapsedRealtime()
        _status.update {
            it.copy(
                connection = ConnectionState.Connected(since, ipLookup.await()),
                tunnelAddress = server.clientAddress.substringBefore(',').substringBefore('/').trim(),
            )
        }
        startWatchdog(tunnel, location, since)
    }

    /** Returns false (and publishes an error) if the backend could not bring the tunnel up. */
    private suspend fun startTunnel(tunnel: IbgTunnel, config: Config): Boolean = try {
        withContext(Dispatchers.IO) { backend.setState(tunnel, Tunnel.State.UP, config) }
        true
    } catch (e: CancellationException) {
        throw e
    } catch (e: BackendException) {
        Log.w(TAG, "Backend error: ${e.reason}")
        activeTunnel = null
        fail(mapBackendError(e)); false
    } catch (e: Exception) {
        Log.w(TAG, "Unexpected start error", e)
        activeTunnel = null
        fail(VpnError.UNKNOWN); false
    }

    private suspend fun awaitHandshake(tunnel: IbgTunnel, sinceEpoch: Long = 0L): Boolean {
        val deadline = SystemClock.elapsedRealtime() + HANDSHAKE_TIMEOUT_MS
        while (SystemClock.elapsedRealtime() < deadline) {
            if (latestHandshake(tunnel) > sinceEpoch) return true
            delay(500)
        }
        return false
    }

    /** Epoch millis of the most recent handshake with any peer, or 0 if none. */
    private fun latestHandshake(tunnel: IbgTunnel): Long = runCatching {
        val stats = backend.getStatistics(tunnel)
        stats.peers().maxOfOrNull { key -> stats.peer(key)?.latestHandshakeEpochMillis() ?: 0L } ?: 0L
    }.getOrDefault(0L)

    /**
     * Watchdog / auto-reconnect. WireGuard re-handshakes roughly every 2 minutes while traffic
     * (including our 25 s keepalive) flows. If the last handshake is older than [STALE_MS], the
     * path is broken: re-create the tunnel once the underlying network is back.
     */
    private fun startWatchdog(tunnel: IbgTunnel, location: VpnLocation, since: Long) {
        watchdogJob = scope.launch {
            var backoff = 5_000L
            while (isActive) {
                delay(WATCHDOG_INTERVAL_MS)
                if (activeTunnel !== tunnel) return@launch
                val age = System.currentTimeMillis() - latestHandshake(tunnel)
                if (age < STALE_MS) { backoff = 5_000L; continue }

                setConnection(ConnectionState.Reconnecting(since))
                if (!network.hasInternet()) continue           // wait for the network to return
                val cfg = activeConfig ?: return@launch
                val before = System.currentTimeMillis()
                val ok = lock.withLock {
                    if (activeTunnel !== tunnel) return@withLock false
                    runCatching { withContext(Dispatchers.IO) {
                        expectedDown = true
                        try { backend.setState(tunnel, Tunnel.State.DOWN, null) } finally { expectedDown = false }
                        backend.setState(tunnel, Tunnel.State.UP, cfg)
                    } }.isSuccess && awaitHandshake(tunnel, before)
                }
                if (ok) {
                    _status.update { it.copy(connection = ConnectionState.Connected(since, PublicIpFetcher.fetch())) }
                    backoff = 5_000L
                } else {
                    Log.i(TAG, "Reconnect to ${location.id} failed; retrying in ${backoff}ms")
                    delay(backoff)
                    backoff = (backoff * 2).coerceAtMost(60_000L)
                }
            }
        }
    }

    private suspend fun bringDown(tunnel: IbgTunnel) {
        expectedDown = true
        try {
            withContext(Dispatchers.IO) { runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) } }
        } finally {
            expectedDown = false
        }
    }

    /** Called by GoBackend. An unexpected DOWN means Android or another VPN app revoked us. */
    private fun onBackendState(tunnel: IbgTunnel, state: Tunnel.State) {
        if (state != Tunnel.State.DOWN || expectedDown || tunnel !== activeTunnel) return
        watchdogJob?.cancel()
        activeTunnel = null
        _status.update { it.copy(connection = ConnectionState.Disconnected, tunnelAddress = null, error = VpnError.REVOKED) }
    }

    private fun setConnection(c: ConnectionState) = _status.update { it.copy(connection = c) }

    private fun fail(error: VpnError) {
        _status.update { it.copy(connection = ConnectionState.Disconnected, tunnelAddress = null, error = error) }
    }

    private fun mapBackendError(e: BackendException): VpnError = when (e.reason) {
        BackendException.Reason.VPN_NOT_AUTHORIZED -> VpnError.PERMISSION_DENIED
        BackendException.Reason.DNS_RESOLUTION_FAILURE -> VpnError.DNS_RESOLUTION
        BackendException.Reason.UNABLE_TO_START_VPN,
        BackendException.Reason.TUN_CREATION_ERROR -> VpnError.START_FAILED
        BackendException.Reason.GO_ACTIVATION_ERROR_CODE -> VpnError.INVALID_CONFIG
        else -> VpnError.UNKNOWN
    }

    private companion object {
        const val TAG = "IbgVpn"
        const val HANDSHAKE_TIMEOUT_MS = 15_000L
        const val WATCHDOG_INTERVAL_MS = 10_000L
        const val STALE_MS = 200_000L
    }
}
