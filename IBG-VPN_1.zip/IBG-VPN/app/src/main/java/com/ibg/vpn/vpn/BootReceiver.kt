package com.ibg.vpn.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.ibg.vpn.IbgVpnApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Starts the VPN after boot, only if the user enabled "Connect when Android starts". */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext as IbgVpnApp
        val settings = app.settingsStore.current
        if (!settings.connectOnBoot) return
        // VPN consent must already have been granted from the UI; we can't show a dialog at boot.
        if (VpnService.prepare(context) != null) return
        if (!app.secureStore.isConfigured(settings.location)) return

        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                // Broadcasts get ~10 s; once the VpnService is running the process is kept alive.
                withTimeoutOrNull(9_000) { app.vpnManager.connectAndAwait(settings.location) }
            } finally {
                pending.finish()
            }
        }
    }
}
