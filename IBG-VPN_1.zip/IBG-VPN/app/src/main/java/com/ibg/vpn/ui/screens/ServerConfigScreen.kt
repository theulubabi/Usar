package com.ibg.vpn.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.ibg.vpn.data.ServerConfig
import com.ibg.vpn.data.VpnLocation
import com.ibg.vpn.ui.MainViewModel

/**
 * Where the real Singapore / Germany WireGuard credentials are entered.
 * Values are validated with the WireGuard parser and saved to EncryptedSharedPreferences.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServerConfigScreen(vm: MainViewModel, location: VpnLocation, onBack: () -> Unit) {
    val initial = remember(location) { vm.loadConfig(location) }
    var host by remember { mutableStateOf(initial.endpointHost) }
    var port by remember { mutableStateOf(initial.port.toString()) }
    var serverPub by remember { mutableStateOf(initial.serverPublicKey) }
    var clientPriv by remember { mutableStateOf(initial.clientPrivateKey) }
    var address by remember { mutableStateOf(initial.clientAddress) }
    var dns by remember { mutableStateOf(initial.dns) }
    var psk by remember { mutableStateOf(initial.presharedKey) }
    var showSecrets by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var importText by remember { mutableStateOf<String?>(null) }

    fun current() = ServerConfig(host, port.toIntOrNull() ?: -1, serverPub, clientPriv, address, dns, psk)

    Scaffold(topBar = {
        TopAppBar(title = { Text("${location.flag} ${location.displayName} server") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } })
    }) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).imePadding().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("Paste the values from your WireGuard server, or import a .conf file's text.",
                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { importText = "" }, modifier = Modifier.fillMaxWidth()) { Text("Import wg-quick .conf text") }

            val secretTx = if (showSecrets) VisualTransformation.None else PasswordVisualTransformation()
            Field("Server IP / Hostname", host, { host = it }, "e.g. sg.example.com or 203.0.113.10")
            Field("Port", port, { port = it.filter(Char::isDigit) }, "51820", keyboard = KeyboardType.Number)
            Field("Server WireGuard Public Key", serverPub, { serverPub = it }, "44-character base64 key")
            Field("Client Private Key", clientPriv, { clientPriv = it }, "Never share this key", tx = secretTx)
            Field("Client IP (Address)", address, { address = it }, "e.g. 10.8.0.2/32")
            Field("DNS", dns, { dns = it }, "e.g. 10.8.0.1 or 1.1.1.1")
            Field("Pre-shared Key (optional)", psk, { psk = it }, "Leave empty if not used", tx = secretTx)
            TextButton(onClick = { showSecrets = !showSecrets }) { Text(if (showSecrets) "Hide keys" else "Show keys") }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { vm.clearConfig(location); onBack() }, modifier = Modifier.weight(1f)) { Text("Clear") }
                Button(modifier = Modifier.weight(1f), onClick = {
                    val cfg = current()
                    message = when {
                        !cfg.isComplete -> "Please fill in every required field (port 1–65535)."
                        else -> runCatching { cfg.toWireGuardConfig() }.fold(
                            onSuccess = { vm.saveConfig(location, cfg); null },
                            onFailure = { "Invalid WireGuard configuration: ${it.message ?: it.javaClass.simpleName}" },
                        )
                    }
                    if (message == null) onBack()
                }) { Text("Save securely") }
            }
            message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }

    importText?.let { text ->
        AlertDialog(
            onDismissRequest = { importText = null },
            title = { Text("Import WireGuard config") },
            text = {
                OutlinedTextField(text, { importText = it }, Modifier.fillMaxWidth().heightIn(min = 180.dp),
                    placeholder = { Text("[Interface]\nPrivateKey = …\nAddress = …\nDNS = …\n\n[Peer]\nPublicKey = …\nEndpoint = host:port") })
            },
            confirmButton = {
                TextButton(onClick = {
                    runCatching { ServerConfig.fromWgQuick(text) }
                        .onSuccess { c ->
                            host = c.endpointHost; port = c.port.toString(); serverPub = c.serverPublicKey
                            clientPriv = c.clientPrivateKey; address = c.clientAddress; dns = c.dns; psk = c.presharedKey
                            message = if (c.dns.isBlank()) "Config imported, but it has no DNS. Add one to prevent DNS leaks." else null
                        }
                        .onFailure { message = "Could not parse config: ${it.message ?: "invalid format"}" }
                    importText = null
                }) { Text("Import") }
            },
            dismissButton = { TextButton(onClick = { importText = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Field(
    label: String, value: String, onChange: (String) -> Unit, hint: String,
    keyboard: KeyboardType = KeyboardType.Ascii, tx: VisualTransformation = VisualTransformation.None,
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, placeholder = { Text(hint) },
        singleLine = true, visualTransformation = tx,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, autoCorrectEnabled = false),
        modifier = Modifier.fillMaxWidth(),
    )
}
