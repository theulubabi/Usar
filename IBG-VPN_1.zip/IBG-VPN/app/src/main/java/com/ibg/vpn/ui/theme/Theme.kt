package com.ibg.vpn.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Mint = Color(0xFF2EE6A6)
val MintDeep = Color(0xFF13B981)
val Amber = Color(0xFFFFB547)
val Navy = Color(0xFF0B1530)

private val DarkColors = darkColorScheme(
    primary = Mint, onPrimary = Navy,
    secondary = Color(0xFF6C8CFF), onSecondary = Color.White,
    background = Color(0xFF070C1A), onBackground = Color(0xFFE7ECF7),
    surface = Color(0xFF111A33), onSurface = Color(0xFFE7ECF7),
    surfaceVariant = Color(0xFF1A2442), onSurfaceVariant = Color(0xFF98A3C0),
    error = Color(0xFFFF6B6B),
)

private val LightColors = lightColorScheme(
    primary = MintDeep, onPrimary = Color.White,
    secondary = Color(0xFF3557E8), onSecondary = Color.White,
    background = Color(0xFFF4F6FB), onBackground = Navy,
    surface = Color.White, onSurface = Navy,
    surfaceVariant = Color(0xFFE6EAF4), onSurfaceVariant = Color(0xFF5A6480),
    error = Color(0xFFD93A3A),
)

@Composable
fun IbgVpnTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
