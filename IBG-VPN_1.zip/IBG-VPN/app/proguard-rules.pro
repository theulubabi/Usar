# WireGuard: native code calls back into these classes by name.
-keep class com.wireguard.** { *; }
-dontwarn com.wireguard.**
# Tink (used by EncryptedSharedPreferences)
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
