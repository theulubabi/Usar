# IBG VPN

Android VPN client (Kotlin · Jetpack Compose · MVVM) that connects to **your own** WireGuard servers in
🇸🇬 Singapore and 🇩🇪 Germany using the official WireGuard Android library (`com.wireguard.android:tunnel`)
and Android `VpnService`. Traffic really goes through the tunnel: the app is a WireGuard client, not a UI mock.

> **Important:** this app is a *client*. It needs two real WireGuard servers (one in Singapore, one in Germany).
> No credentials are bundled. Until you enter them, each location shows **"Not configured"** and connecting
> shows a clear error.

---

## 1. Project layout

```
app/src/main/java/com/ibg/vpn/
├── IbgVpnApp.kt              # Application + simple dependency container
├── MainActivity.kt           # Compose navigation host
├── data/
│   ├── VpnLocation.kt        # Singapore / Germany definitions (flag, tunnel name)
│   ├── ServerConfig.kt       # Fields → WireGuard Config (full tunnel, DNS, IPv6 handling); .conf import
│   ├── SecureConfigStore.kt  # EncryptedSharedPreferences, key in Android Keystore
│   └── SettingsStore.kt      # Non-secret prefs (location, auto-connect, boot, kill switch)
├── vpn/
│   ├── VpnManager.kt         # Connect/disconnect, handshake verification, watchdog/auto-reconnect
│   ├── NetworkMonitor.kt     # Detects real (non-VPN) internet availability
│   ├── PublicIpFetcher.kt    # HTTPS exit-IP check (through the tunnel)
│   ├── IbgTunnel.kt          # WireGuard Tunnel implementation
│   ├── ConnectionState.kt    # UI states + user-facing errors
│   └── BootReceiver.kt       # "Connect when Android starts"
└── ui/
    ├── MainViewModel.kt
    ├── theme/Theme.kt        # Dark + light themes
    └── screens/              # Home, ConnectButton, Location, Settings, ServerConfig
```

## 2. How the security requirements are met

| Requirement | Implementation |
|---|---|
| Real routing | WireGuard `GoBackend` creates a TUN interface via `VpnService`; `AllowedIPs = 0.0.0.0/0, ::/0` sends all traffic into the tunnel. |
| No false "Connected" | `VpnManager` reports **Protected** only after the backend is UP **and** a WireGuard handshake with the server is observed (15 s timeout). Otherwise the tunnel is torn down and an error is shown. |
| DNS leak prevention | DNS is mandatory in the config and pushed to the VPN interface; since every route goes into the tunnel, DNS queries do too. |
| IPv6 leaks | `::/0` is routed into the tunnel. If your server has no IPv6, IPv6 packets are dropped inside the tunnel instead of leaking. |
| Auto-reconnect | Watchdog checks handshake age every 10 s; if older than 200 s and a real network is present, the tunnel is rebuilt with exponential backoff. WireGuard also roams between Wi-Fi/mobile natively. |
| Kill switch | Android only lets the *system* enforce this. The toggle guides the user to **Settings → VPN → IBG VPN → Always-on VPN + Block connections without VPN**. The app handles the always-on start callback. |
| Secure storage | Keys stored with `EncryptedSharedPreferences` (AES-256-GCM, master key in Android Keystore). Backup and device transfer are disabled. |
| No hard-coded keys | Nothing secret is in source. Credentials are entered on-device. |
| Privacy | No analytics, no trackers, no logs of browsing. One HTTPS request to `IP_CHECK_URL` (via the tunnel) displays the VPN IP — change it in `app/build.gradle.kts` to an endpoint on your own server if you prefer. |
| Permissions | `INTERNET`, `ACCESS_NETWORK_STATE`, `RECEIVE_BOOT_COMPLETED` only. Cleartext HTTP is disabled. |

## 3. Setting up the servers (Singapore & Germany)

You need a Linux VPS in each country (any provider with Singapore and Frankfurt regions works).
On **each** server:

```bash
sudo apt update && sudo apt install -y wireguard
umask 077
wg genkey | tee server.key | wg pubkey > server.pub
wg genkey | tee client.key | wg pubkey > client.pub

# Enable forwarding
echo "net.ipv4.ip_forward=1" | sudo tee /etc/sysctl.d/99-wg.conf && sudo sysctl --system
```

`/etc/wireguard/wg0.conf` (replace `eth0` with your public interface and paste the keys):

```ini
[Interface]
Address = 10.8.0.1/24
ListenPort = 51820
PrivateKey = <contents of server.key>
PostUp   = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

[Peer]
PublicKey = <contents of client.pub>
AllowedIPs = 10.8.0.2/32
```

```bash
sudo systemctl enable --now wg-quick@wg0
# Open UDP 51820 in the server/cloud firewall.
```

Use a different client key pair per server (and per phone) — never reuse keys.

## 4. Entering the real credentials in the app  ← where the placeholders are

There are **no credential placeholders in code** by design. Open the app → ⚙ **Settings → Servers → Singapore**
(then **Germany**) and fill in:

| App field | Value |
|---|---|
| Server IP / Hostname | Public IP or DNS name of the Singapore (or Germany) VPS |
| Port | `51820` (or your `ListenPort`) |
| Server WireGuard Public Key | contents of that server's `server.pub` |
| Client Private Key | contents of that server's `client.key` |
| Client IP (Address) | `10.8.0.2/32` (must match the server's `AllowedIPs` for this peer) |
| DNS | e.g. `1.1.1.1` (or a resolver running on the server, e.g. `10.8.0.1`) |
| Pre-shared Key | optional |

Or tap **Import wg-quick .conf text** and paste a standard client config:

```ini
[Interface]
PrivateKey = <client.key>
Address = 10.8.0.2/32
DNS = 1.1.1.1

[Peer]
PublicKey = <server.pub>
Endpoint = sg.example.com:51820
AllowedIPs = 0.0.0.0/0, ::/0
```

Press **Save securely**. The input is validated by the WireGuard parser before it is stored encrypted.
To replace credentials later, open the same screen, edit, and save (or press **Clear**).

## 5. Building the APK

### Option A — Android Studio (recommended)
1. Install Android Studio (Ladybug 2024.2 or newer).
2. **File → Open** → select this folder. Let Gradle sync (it downloads Gradle 8.11.1, AGP 8.7.3, SDK 35).
3. Debug APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**
   → `app/build/outputs/apk/debug/app-debug.apk`

### Option B — command line
```bash
# One-time: generate the wrapper jar (needs a local Gradle 8.x install)
gradle wrapper --gradle-version 8.11.1
./gradlew :app:assembleDebug        # → app/build/outputs/apk/debug/app-debug.apk
```

### Option C — GitHub Actions (no local setup)
Push the project to a GitHub repo. The included workflow `.github/workflows/build-apk.yml` builds
the APK on every push; download it from **Actions → latest run → Artifacts → ibg-vpn-apks**.

### Signed release APK
```bash
keytool -genkeypair -v -keystore ibg-release.jks -alias ibgvpn -keyalg RSA -keysize 4096 -validity 10000
cp keystore.properties.example keystore.properties   # fill in passwords
./gradlew :app:assembleRelease      # → app/build/outputs/apk/release/app-release.apk
```
Without `keystore.properties`, the release build is produced **unsigned** and can't be installed.
For GitHub Actions, add secrets `KEYSTORE_BASE64` (`base64 -w0 ibg-release.jks`), `STORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD`. Keep the keystore safe: losing it means you can't publish updates.

## 6. Installing the APK
- **USB:** enable Developer options → USB debugging, then `adb install -r app-debug.apk`.
- **On the phone:** copy the APK, open it, allow *Install unknown apps* for your file manager when asked.
- Debug builds install as `com.ibg.vpn.debug`, so they can live next to the release build.

## 7. Test checklist (run on a real device)

| # | Test | How to verify |
|---|---|---|
| 1 | Installs | `adb install` succeeds |
| 2 | Launches | Home screen shows **Not Connected** |
| 3 | VPN permission dialog | First tap on the button shows Android's "Connection request"; tapping Cancel shows the permission error |
| 4 | Singapore uses SG config | Select 🇸🇬, connect → VPN IP equals the Singapore server's public IP |
| 5 | Germany uses DE config | Select 🇩🇪, connect → VPN IP equals the German server's public IP |
| 6 | Connect / Disconnect | Key icon appears/disappears in the status bar; timer starts/stops |
| 7 | Traffic routed | Open https://ipleak.net in Chrome: IP + country match the server. On server: `sudo wg show` shows rising transfer |
| 8 | DNS doesn't bypass | ipleak.net / dnsleaktest.com "extended test": only resolvers from your configured DNS appear |
| 9 | No false "Connected" | Enter a wrong server public key or stop `wg-quick@wg0` → app shows an error after ~15 s, never "Protected" |
| 10 | Rebuild | `./gradlew clean assembleDebug` succeeds |

Also try: toggling airplane mode while connected (should show *Reconnecting…* then *Protected*), and
enabling *Connect when Android starts* then rebooting.

## 8. Notes & limitations
- The kill switch can't be force-enabled by a normal app; Android requires the user to turn on
  "Block connections without VPN" in system settings (the app takes them there).
- Only one VPN can be active on Android at a time; starting another VPN app disconnects IBG VPN (shown as an error).
- Handshake verification proves packets reach your server and come back. If the server forgets NAT/forwarding,
  the handshake still succeeds but browsing fails — the "VPN IP: Unavailable" label is the hint to check server forwarding.
